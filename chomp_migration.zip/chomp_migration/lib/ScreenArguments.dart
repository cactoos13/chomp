class ScreenArguments {
//  final String title;
  final String message;

//  ScreenArguments(this.title, this.message);
  ScreenArguments(this.message);
}